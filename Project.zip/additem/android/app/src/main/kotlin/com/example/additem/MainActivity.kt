package com.example.additem

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
